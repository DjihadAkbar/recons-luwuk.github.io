<footer id="footer">
    <nav class="navbar navbark-dark bg-dark text-light">
        <h5> &#169; Copyright 2023</h5>
    </nav>
</footer>

</body>

</html>