<?php


echo $namaLintasan;
echo $bulan;
echo $tahun;
echo $valueTarif;